# frameworks

## [W3CSS](https://www.w3schools.com/w3css/defaulT.asp)
Alternative à Bootstrap (sans jquery, ni lib js)
* [exemples par catégories](https://www.w3schools.com/w3css/w3css_examples.asp)

## BOOTSTRAP 4
* [w3schools](https://www.w3schools.com/bootstrap4/default.asp)
* [tuto fr](https://tutowebdesign.com/bien-demarrer-bootstrap-4.php)

## DIVERS
* [icones](https://www.w3schools.com/icons/icons_reference.asp)
* [google fonts](https://www.w3schools.com/howto/howto_google_fonts.asp)